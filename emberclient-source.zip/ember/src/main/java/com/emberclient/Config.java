package com.emberclient;
import java.io.*; import java.nio.file.*; import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
public final class Config {
  static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("emberclient.properties"); }
  public static void load() {
    try (InputStream in = Files.newInputStream(file())) { Properties p = new Properties(); p.load(in);
      for (Module m : Modules.ALL) if (p.containsKey(m.name)) m.enabled = Boolean.parseBoolean(p.getProperty(m.name));
    } catch (IOException ignored) {}
  }
  public static void save() {
    Properties p = new Properties();
    for (Module m : Modules.ALL) p.setProperty(m.name, String.valueOf(m.enabled));
    try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Ember Client"); } catch (IOException ignored) {}
  }
}
