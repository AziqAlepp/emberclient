package com.emberclient;
import net.minecraft.client.MinecraftClient;
public abstract class Module {
  public final String name, desc;
  public boolean enabled;
  protected Module(String name, String desc, boolean on) { this.name = name; this.desc = desc; this.enabled = on; }
  public void toggle() { enabled = !enabled; if (enabled) onEnable(MinecraftClient.getInstance()); else onDisable(MinecraftClient.getInstance()); Config.save(); }
  public void onEnable(MinecraftClient mc) {}
  public void onDisable(MinecraftClient mc) {}
  public void onTick(MinecraftClient mc) {}
  /** One-line HUD text, or null for none. */
  public String hudText(MinecraftClient mc) { return null; }
}
