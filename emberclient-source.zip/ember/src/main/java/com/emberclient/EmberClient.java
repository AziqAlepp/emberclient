package com.emberclient;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.EquipmentSlot;
import org.lwjgl.glfw.GLFW;

public class EmberClient implements ClientModInitializer {
  static KeyBinding guiKey;

  @Override public void onInitializeClient() {
    Modules.init(); Config.load();
    guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.emberclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.emberclient"));
    Modules.zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.emberclient.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.emberclient"));
    ClientTickEvents.END_CLIENT_TICK.register(mc -> {
      while (guiKey.wasPressed()) mc.setScreen(new ClickGui());
      for (Module m : Modules.ALL) if (m.enabled) m.onTick(mc);
    });
    HudRenderCallback.EVENT.register(EmberClient::hud);
  }

  static void hud(DrawContext c, net.minecraft.client.render.RenderTickCounter t) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (mc.options.hudHidden || mc.player == null) return;
    int y = 4;
    for (Module m : Modules.ALL) {
      if (!m.enabled) continue;
      String s = m.hudText(mc); if (s == null) continue;
      int w = mc.textRenderer.getWidth(s);
      c.fill(4, y, 4 + w + 8, y + 12, Theme.BG);
      c.fill(4, y, 6, y + 12, Theme.ACCENT);
      c.drawTextWithShadow(mc.textRenderer, s, 10, y + 2, Theme.TEXT);
      y += 14;
    }
    if (Modules.KEYS.enabled) keys(c, mc, 4, y + 6);
    if (Modules.ARMOR.enabled) armor(c, mc);
  }

  static void keys(DrawContext c, MinecraftClient mc, int x, int y) {
    var o = mc.options;
    key(c, mc, "W", o.forwardKey.isPressed(), x + 20, y);
    key(c, mc, "A", o.leftKey.isPressed(), x, y + 20);
    key(c, mc, "S", o.backKey.isPressed(), x + 20, y + 20);
    key(c, mc, "D", o.rightKey.isPressed(), x + 40, y + 20);
  }
  static void key(DrawContext c, MinecraftClient mc, String l, boolean on, int x, int y) {
    c.fill(x, y, x + 18, y + 18, on ? Theme.ACCENT : Theme.BG);
    c.drawCenteredTextWithShadow(mc.textRenderer, l, x + 9, y + 5, on ? 0xFF141318 : Theme.TEXT);
  }

  static void armor(DrawContext c, MinecraftClient mc) {
    EquipmentSlot[] s = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
    int x = c.getScaledWindowWidth() - 22, y = 4;
    for (EquipmentSlot sl : s) {
      ItemStack st = mc.player.getEquippedStack(sl);
      if (st.isEmpty()) continue;
      c.drawItem(st, x, y);
      if (st.isDamageable()) {
        String d = String.valueOf(st.getMaxDamage() - st.getDamage());
        c.drawTextWithShadow(mc.textRenderer, d, x - mc.textRenderer.getWidth(d) - 2, y + 4, Theme.TEXT);
      }
      y += 18;
    }
  }
}
