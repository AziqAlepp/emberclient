package com.emberclient;
public final class Theme {
  public static final int BG = 0xE6141318, PANEL = 0xFF1E1C24, HOVER = 0xFF2A2732;
  public static final int ACCENT = 0xFFFF8A3D, ON = 0xFFFFB26B, OFF = 0xFF6B6672, TEXT = 0xFFEDEAF2;
}
