package com.emberclient;
import java.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.*;
import net.minecraft.entity.effect.*;
import org.lwjgl.glfw.GLFW;

public final class Modules {
  public static final List<Module> ALL = new ArrayList<>();
  public static Module FPS, CPS, SPRINT, ZOOM, FULLBRIGHT, KEYS, ARMOR, BOOST;
  public static net.minecraft.client.option.KeyBinding zoomKey;

  public static void init() {
    FPS = add(new Module("FPS Display", "Shows current FPS", true) {
      public String hudText(MinecraftClient mc) { return "FPS: " + mc.getCurrentFps(); } });

    CPS = add(new Module("CPS Display", "Shows clicks per second", true) {
      final Deque<Long> clicks = new ArrayDeque<>(); boolean was;
      public String hudText(MinecraftClient mc) {
        boolean d = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (d && !was) clicks.add(now);
        was = d;
        while (!clicks.isEmpty() && now - clicks.peek() > 1000) clicks.poll();
        return "CPS: " + clicks.size();
      } });

    SPRINT = add(new Module("Toggle Sprint", "Auto sprint while moving forward", false) {
      public void onTick(MinecraftClient mc) {
        var p = mc.player; if (p == null) return;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6)
          p.setSprinting(true);
      }
      public String hudText(MinecraftClient mc) { return "Sprint: ON"; } });

    ZOOM = add(new Module("Zoom", "Hold C to zoom", true) {
      Integer saved;
      public void onTick(MinecraftClient mc) {
        boolean z = zoomKey != null && zoomKey.isPressed() && mc.currentScreen == null;
        var fov = mc.options.getFov();
        if (z && saved == null) { saved = fov.getValue(); fov.setValue(30); }
        else if (!z && saved != null) { fov.setValue(saved); saved = null; }
      } });

    FULLBRIGHT = add(new Module("Fullbright", "Max brightness", false) {
      public void onTick(MinecraftClient mc) {
        if (mc.player != null) mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
      }
      public void onDisable(MinecraftClient mc) { if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); } });

    KEYS = add(new Module("Keystrokes", "WASD display", true) {});
    ARMOR = add(new Module("Armor HUD", "Shows armor durability", true) {});

    BOOST = add(new Module("FPS Boost", "Lighter settings for low-end devices", false) {
      public void onEnable(MinecraftClient mc) {
        GameOptions o = mc.options;
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getViewDistance().setValue(6);
        o.getSimulationDistance().setValue(5);
        o.getEntityDistanceScaling().setValue(0.5);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getBiomeBlendRadius().setValue(0);
        o.getMipmapLevels().setValue(0);
        o.getAo().setValue(false);
        o.getEntityShadows().setValue(false);
        o.getBobView().setValue(false);
        o.write();
      } });
  }

  static Module add(Module m) { ALL.add(m); return m; }
}
