package com.emberclient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ClickGui extends Screen {
  static final int W = 220, ROW = 26;
  public ClickGui() { super(Text.literal("Ember")); }
  int px() { return (width - W) / 2; }
  int py() { return (height - (Modules.ALL.size() * ROW + 34)) / 2; }

  @Override public void render(DrawContext c, int mx, int my, float d) {
    super.render(c, mx, my, d);
    int x = px(), y = py(), h = Modules.ALL.size() * ROW + 34;
    c.fill(x - 1, y - 1, x + W + 1, y + h + 1, Theme.ACCENT);
    c.fill(x, y, x + W, y + h, Theme.PANEL);
    c.fill(x, y, x + W, y + 26, Theme.BG);
    c.drawTextWithShadow(textRenderer, "EMBER", x + 10, y + 9, Theme.ACCENT);
    c.drawTextWithShadow(textRenderer, "client", x + 48, y + 9, Theme.OFF);
    int ry = y + 30;
    for (Module m : Modules.ALL) {
      boolean hov = mx >= x && mx < x + W && my >= ry && my < ry + ROW;
      if (hov) c.fill(x, ry, x + W, ry + ROW, Theme.HOVER);
      c.drawTextWithShadow(textRenderer, m.name, x + 10, ry + 9, Theme.TEXT);
      int sx = x + W - 36;
      c.fill(sx, ry + 7, sx + 26, ry + 19, m.enabled ? Theme.ACCENT : Theme.OFF);
      int kx = m.enabled ? sx + 15 : sx + 2;
      c.fill(kx, ry + 9, kx + 9, ry + 17, Theme.TEXT);
      ry += ROW;
    }
  }

  @Override public boolean mouseClicked(double mx, double my, int b) {
    int x = px(), ry = py() + 30;
    for (Module m : Modules.ALL) {
      if (mx >= x && mx < x + W && my >= ry && my < ry + ROW) { m.toggle(); return true; }
      ry += ROW;
    }
    return super.mouseClicked(mx, my, b);
  }
  @Override public boolean shouldPause() { return false; }
}
