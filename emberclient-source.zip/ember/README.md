# Ember Client (Fabric 1.21.4)
Build: push to GitHub, run the "build" Action, download the jar from Artifacts. Or locally: `gradle build` (Java 21).
Needs Fabric Loader + Fabric API. Right Shift = menu, C = zoom. Pair with Sodium + Lithium for best FPS.
Rename: edit "emberclient"/"Ember" in fabric.mod.json, Theme.java, ClickGui.java, build.gradle.
